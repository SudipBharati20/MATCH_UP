// ============================================================
//  FIFA SIM — Player & Team Database (FC 26 Ratings)
// ============================================================

const LEAGUES = {
  premierLeague: { name: "Premier League", country: "England", color: "#3d195b" },
  laLiga:        { name: "La Liga",         country: "Spain",   color: "#ee8707" },
  serieA:        { name: "Serie A",         country: "Italy",   color: "#1a56db" },
  bundesliga:    { name: "Bundesliga",      country: "Germany", color: "#d4021d" },
  ligue1:        { name: "Ligue 1",         country: "France",  color: "#091c3e" },
};

const TEAMS = {
  // ── PREMIER LEAGUE ─────────────────────────────────────────
  manchester_city: {
    id: "manchester_city", name: "Manchester City", league: "premierLeague",
    color: "#6CABDD", color2: "#FFFFFF", rating: 88,
    formation: "4-3-3",
    players: [
      { id:"edc",  name:"Ederson",        pos:"GK",  rating:90, pace:45, shooting:15, passing:70, dribbling:40, defending:25, physical:82 },
      { id:"wal",  name:"K. Walker",      pos:"RB",  rating:83, pace:92, shooting:55, passing:72, dribbling:70, defending:80, physical:80 },
      { id:"rup",  name:"R. Dias",        pos:"CB",  rating:88, pace:70, shooting:42, passing:75, dribbling:62, defending:91, physical:86 },
      { id:"ake",  name:"N. Aké",         pos:"CB",  rating:83, pace:73, shooting:40, passing:70, dribbling:65, defending:85, physical:83 },
      { id:"gvd",  name:"J. Gvardiol",    pos:"LB",  rating:85, pace:82, shooting:52, passing:76, dribbling:75, defending:84, physical:82 },
      { id:"rod",  name:"R. Rodri",       pos:"CDM", rating:91, pace:60, shooting:70, passing:90, dribbling:80, defending:88, physical:83 },
      { id:"deb",  name:"K. De Bruyne",   pos:"CM",  rating:91, pace:76, shooting:86, passing:96, dribbling:88, defending:64, physical:78 },
      { id:"ber",  name:"B. Silva",       pos:"CM",  rating:87, pace:78, shooting:76, passing:90, dribbling:89, defending:70, physical:68 },
      { id:"doku", name:"J. Doku",        pos:"LW",  rating:84, pace:97, shooting:75, passing:74, dribbling:91, defending:35, physical:68 },
      { id:"haa",  name:"E. Haaland",     pos:"ST",  rating:94, pace:89, shooting:97, passing:65, dribbling:80, defending:45, physical:92 },
      { id:"sav",  name:"İ. Gündoğan",    pos:"RW",  rating:84, pace:69, shooting:78, passing:88, dribbling:83, defending:60, physical:72 },
    ]
  },
  arsenal: {
    id: "arsenal", name: "Arsenal", league: "premierLeague",
    color: "#EF0107", color2: "#FFFFFF", rating: 87,
    formation: "4-3-3",
    players: [
      { id:"ram",  name:"D. Raya",        pos:"GK",  rating:87, pace:40, shooting:12, passing:72, dribbling:38, defending:22, physical:78 },
      { id:"whi",  name:"B. White",       pos:"RB",  rating:84, pace:80, shooting:55, passing:75, dribbling:73, defending:83, physical:78 },
      { id:"mag",  name:"G. Magalhães",   pos:"CB",  rating:86, pace:71, shooting:44, passing:72, dribbling:66, defending:88, physical:87 },
      { id:"sal",  name:"W. Saliba",      pos:"CB",  rating:89, pace:80, shooting:40, passing:74, dribbling:70, defending:90, physical:85 },
      { id:"zin",  name:"O. Zinchenko",   pos:"LB",  rating:82, pace:76, shooting:60, passing:84, dribbling:80, defending:75, physical:68 },
      { id:"par",  name:"T. Partey",      pos:"CDM", rating:85, pace:72, shooting:70, passing:81, dribbling:76, defending:84, physical:84 },
      { id:"ode",  name:"M. Ødegaard",    pos:"CM",  rating:90, pace:75, shooting:82, passing:92, dribbling:89, defending:62, physical:68 },
      { id:"ric",  name:"D. Rice",        pos:"CM",  rating:87, pace:76, shooting:72, passing:84, dribbling:78, defending:86, physical:82 },
      { id:"sak",  name:"B. Saka",        pos:"RW",  rating:90, pace:88, shooting:82, passing:85, dribbling:91, defending:60, physical:72 },
      { id:"hav",  name:"K. Havertz",     pos:"ST",  rating:84, pace:76, shooting:80, passing:78, dribbling:80, defending:55, physical:78 },
      { id:"mar",  name:"L. Trossard",    pos:"LW",  rating:83, pace:80, shooting:79, passing:80, dribbling:82, defending:42, physical:70 },
    ]
  },
  liverpool: {
    id: "liverpool", name: "Liverpool", league: "premierLeague",
    color: "#C8102E", color2: "#00B2A9", rating: 88,
    formation: "4-3-3",
    players: [
      { id:"ali",  name:"Alisson",        pos:"GK",  rating:91, pace:42, shooting:14, passing:75, dribbling:42, defending:28, physical:80 },
      { id:"ale",  name:"T. Alexander-Arnold", pos:"RB", rating:88, pace:80, shooting:78, passing:95, dribbling:80, defending:76, physical:72 },
      { id:"konate",name:"I. Konaté",     pos:"CB",  rating:86, pace:82, shooting:38, passing:68, dribbling:63, defending:87, physical:90 },
      { id:"van",  name:"V. van Dijk",    pos:"CB",  rating:91, pace:78, shooting:60, passing:82, dribbling:72, defending:94, physical:90 },
      { id:"rob",  name:"A. Robertson",   pos:"LB",  rating:87, pace:86, shooting:62, passing:87, dribbling:80, defending:83, physical:78 },
      { id:"gra",  name:"A. Mac Allister",pos:"CM",  rating:85, pace:70, shooting:74, passing:85, dribbling:80, defending:74, physical:76 },
      { id:"sza",  name:"D. Szoboszlai",  pos:"CM",  rating:85, pace:80, shooting:80, passing:84, dribbling:85, defending:65, physical:76 },
      { id:"end",  name:"R. Endo",        pos:"CDM", rating:82, pace:64, shooting:64, passing:80, dribbling:74, defending:82, physical:78 },
      { id:"sal",  name:"M. Salah",       pos:"RW",  rating:92, pace:90, shooting:90, passing:84, dribbling:92, defending:45, physical:76 },
      { id:"nun",  name:"D. Núñez",       pos:"ST",  rating:86, pace:93, shooting:84, passing:72, dribbling:80, defending:40, physical:82 },
      { id:"gak",  name:"C. Gakpo",       pos:"LW",  rating:84, pace:84, shooting:80, passing:78, dribbling:84, defending:40, physical:76 },
    ]
  },
  chelsea: {
    id: "chelsea", name: "Chelsea", league: "premierLeague",
    color: "#034694", color2: "#FFFFFF", rating: 84,
    formation: "4-2-3-1",
    players: [
      { id:"san",  name:"R. Sánchez",     pos:"GK",  rating:84, pace:38, shooting:12, passing:68, dribbling:36, defending:20, physical:76 },
      { id:"reece",name:"R. James",       pos:"RB",  rating:87, pace:85, shooting:72, passing:82, dribbling:82, defending:86, physical:82 },
      { id:"col",  name:"W. Fofana",      pos:"CB",  rating:84, pace:82, shooting:38, passing:68, dribbling:65, defending:85, physical:84 },
      { id:"chala",name:"B. Chalobah",    pos:"CB",  rating:80, pace:74, shooting:36, passing:65, dribbling:60, defending:80, physical:82 },
      { id:"cui",  name:"M. Cucurella",   pos:"LB",  rating:82, pace:78, shooting:50, passing:74, dribbling:76, defending:80, physical:72 },
      { id:"caicedo",name:"M. Caicedo",   pos:"CDM", rating:86, pace:72, shooting:68, passing:80, dribbling:78, defending:86, physical:82 },
      { id:"enzo", name:"E. Fernández",   pos:"CM",  rating:85, pace:74, shooting:76, passing:87, dribbling:83, defending:76, physical:76 },
      { id:"pahinha",name:"P. Neto",      pos:"RW",  rating:83, pace:90, shooting:74, passing:76, dribbling:88, defending:38, physical:68 },
      { id:"col2", name:"C. Palmer",      pos:"CAM", rating:87, pace:74, shooting:84, passing:88, dribbling:90, defending:42, physical:68 },
      { id:"mud",  name:"N. Madueke",     pos:"LW",  rating:82, pace:87, shooting:76, passing:74, dribbling:87, defending:36, physical:68 },
      { id:"jackson","name":"N. Jackson", pos:"ST",  rating:83, pace:88, shooting:82, passing:72, dribbling:80, defending:38, physical:78 },
    ]
  },

  // ── LA LIGA ────────────────────────────────────────────────
  real_madrid: {
    id: "real_madrid", name: "Real Madrid", league: "laLiga",
    color: "#FEBE10", color2: "#FFFFFF", rating: 90,
    formation: "4-3-3",
    players: [
      { id:"cour",  name:"T. Courtois",   pos:"GK",  rating:92, pace:44, shooting:14, passing:76, dribbling:44, defending:30, physical:83 },
      { id:"carvajal",name:"D. Carvajal", pos:"RB",  rating:87, pace:83, shooting:62, passing:82, dribbling:80, defending:86, physical:80 },
      { id:"mili",  name:"E. Militão",    pos:"CB",  rating:87, pace:82, shooting:44, passing:72, dribbling:68, defending:89, physical:85 },
      { id:"rud",   name:"A. Rüdiger",    pos:"CB",  rating:86, pace:80, shooting:46, passing:70, dribbling:68, defending:88, physical:88 },
      { id:"men",   name:"F. Mendy",      pos:"LB",  rating:84, pace:86, shooting:52, passing:75, dribbling:75, defending:83, physical:80 },
      { id:"cam",   name:"A. Camavinga",  pos:"CM",  rating:86, pace:84, shooting:72, passing:84, dribbling:88, defending:76, physical:76 },
      { id:"tchou", name:"A. Tchouaméni", pos:"CDM", rating:86, pace:73, shooting:70, passing:80, dribbling:76, defending:86, physical:84 },
      { id:"bel",   name:"F. Valverde",   pos:"CM",  rating:88, pace:86, shooting:80, passing:84, dribbling:84, defending:76, physical:84 },
      { id:"vini",  name:"Vinicius Jr.",  pos:"LW",  rating:93, pace:97, shooting:86, passing:80, dribbling:95, defending:30, physical:74 },
      { id:"mba",   name:"K. Mbappé",     pos:"ST",  rating:94, pace:98, shooting:93, passing:82, dribbling:93, defending:38, physical:80 },
      { id:"rod2",  name:"R. González",   pos:"RW",  rating:86, pace:88, shooting:80, passing:80, dribbling:88, defending:42, physical:72 },
    ]
  },
  barcelona: {
    id: "barcelona", name: "Barcelona", league: "laLiga",
    color: "#A50044", color2: "#004D98", rating: 87,
    formation: "4-3-3",
    players: [
      { id:"szc",  name:"M. ter Stegen",  pos:"GK",  rating:90, pace:42, shooting:14, passing:80, dribbling:42, defending:28, physical:78 },
      { id:"kounde",name:"J. Koundé",     pos:"RB",  rating:86, pace:85, shooting:56, passing:76, dribbling:76, defending:87, physical:76 },
      { id:"cub",  name:"R. Cubarsí",     pos:"CB",  rating:84, pace:76, shooting:40, passing:78, dribbling:72, defending:86, physical:80 },
      { id:"ina",  name:"A. Iñigo Martínez",pos:"CB",rating:82, pace:72, shooting:38, passing:72, dribbling:65, defending:85, physical:82 },
      { id:"bal",  name:"A. Balde",       pos:"LB",  rating:84, pace:90, shooting:58, passing:76, dribbling:82, defending:78, physical:76 },
      { id:"pedo", name:"Pedri",          pos:"CM",  rating:90, pace:78, shooting:74, passing:90, dribbling:92, defending:66, physical:65 },
      { id:"gavi", name:"Gavi",           pos:"CM",  rating:88, pace:80, shooting:74, passing:87, dribbling:89, defending:70, physical:72 },
      { id:"cas3",  name:"D. de Jong",    pos:"CDM", rating:87, pace:78, shooting:70, passing:88, dribbling:86, defending:74, physical:76 },
      { id:"yam",  name:"L. Yamal",       pos:"RW",  rating:90, pace:92, shooting:80, passing:84, dribbling:93, defending:32, physical:64 },
      { id:"lewa", name:"R. Lewandowski", pos:"ST",  rating:91, pace:72, shooting:95, passing:78, dribbling:82, defending:42, physical:82 },
      { id:"raphi",name:"R. Alcântara",   pos:"LW",  rating:86, pace:85, shooting:76, passing:78, dribbling:87, defending:38, physical:68 },
    ]
  },
  atletico_madrid: {
    id: "atletico_madrid", name: "Atlético Madrid", league: "laLiga",
    color: "#CE3524", color2: "#272E61", rating: 85,
    formation: "4-4-2",
    players: [
      { id:"obl",  name:"J. Oblak",       pos:"GK",  rating:91, pace:40, shooting:12, passing:68, dribbling:38, defending:26, physical:80 },
      { id:"mol",  name:"M. Molina",      pos:"RB",  rating:83, pace:84, shooting:64, passing:76, dribbling:76, defending:80, physical:76 },
      { id:"gim",  name:"J. Giménez",     pos:"CB",  rating:86, pace:76, shooting:42, passing:68, dribbling:63, defending:88, physical:86 },
      { id:"wi",   name:"A. Witsel",      pos:"CB",  rating:82, pace:64, shooting:52, passing:75, dribbling:68, defending:84, physical:82 },
      { id:"rie",  name:"R. Lodi",        pos:"LB",  rating:83, pace:86, shooting:58, passing:76, dribbling:80, defending:76, physical:74 },
      { id:"koke", name:"Koke",           pos:"CM",  rating:84, pace:72, shooting:68, passing:88, dribbling:82, defending:72, physical:72 },
      { id:"mar2", name:"M. de Paul",     pos:"CM",  rating:85, pace:78, shooting:76, passing:85, dribbling:83, defending:76, physical:80 },
      { id:"lior", name:"S. Llorente",    pos:"CM",  rating:82, pace:74, shooting:72, passing:80, dribbling:76, defending:72, physical:76 },
      { id:"gri",  name:"A. Griezmann",   pos:"ST",  rating:88, pace:80, shooting:87, passing:85, dribbling:87, defending:52, physical:74 },
      { id:"alv2", name:"Á. Morata",      pos:"ST",  rating:83, pace:80, shooting:82, passing:72, dribbling:76, defending:42, physical:80 },
      { id:"sam",  name:"S. Lino",        pos:"LM",  rating:82, pace:88, shooting:70, passing:74, dribbling:84, defending:38, physical:68 },
    ]
  },

  // ── SERIE A ────────────────────────────────────────────────
  inter_milan: {
    id: "inter_milan", name: "Inter Milan", league: "serieA",
    color: "#010E80", color2: "#000000", rating: 87,
    formation: "3-5-2",
    players: [
      { id:"soma",  name:"Y. Sommer",     pos:"GK",  rating:87, pace:38, shooting:12, passing:70, dribbling:36, defending:24, physical:78 },
      { id:"pav",   name:"B. Pavard",     pos:"CB",  rating:85, pace:78, shooting:52, passing:76, dribbling:72, defending:86, physical:82 },
      { id:"acerbi",name:"F. Acerbi",     pos:"CB",  rating:85, pace:66, shooting:40, passing:72, dribbling:64, defending:88, physical:82 },
      { id:"bast",  name:"A. Bastoni",    pos:"CB",  rating:88, pace:74, shooting:46, passing:84, dribbling:76, defending:88, physical:82 },
      { id:"dam",   name:"D. D'Ambrosio", pos:"RWB", rating:80, pace:80, shooting:58, passing:72, dribbling:74, defending:80, physical:78 },
      { id:"bar",   name:"N. Barella",    pos:"CM",  rating:90, pace:84, shooting:78, passing:87, dribbling:86, defending:76, physical:84 },
      { id:"cal",   name:"H. Çalhanoglu", pos:"CDM", rating:87, pace:68, shooting:80, passing:89, dribbling:83, defending:72, physical:74 },
      { id:"mhit",  name:"H. Mkhitaryan", pos:"CM",  rating:83, pace:72, shooting:76, passing:84, dribbling:80, defending:68, physical:72 },
      { id:"dia2",  name:"F. Dimarco",    pos:"LWB", rating:85, pace:82, shooting:68, passing:84, dribbling:80, defending:80, physical:74 },
      { id:"thu",   name:"M. Thuram",     pos:"ST",  rating:86, pace:90, shooting:82, passing:72, dribbling:82, defending:38, physical:84 },
      { id:"lau",   name:"L. Martínez",   pos:"ST",  rating:89, pace:84, shooting:89, passing:74, dribbling:83, defending:38, physical:82 },
    ]
  },
  juventus: {
    id: "juventus", name: "Juventus", league: "serieA",
    color: "#000000", color2: "#FFFFFF", rating: 84,
    formation: "4-2-3-1",
    players: [
      { id:"szcz",  name:"W. Szczęsny",   pos:"GK",  rating:86, pace:38, shooting:12, passing:68, dribbling:36, defending:22, physical:78 },
      { id:"dan2",  name:"D. Danilo",     pos:"RB",  rating:83, pace:76, shooting:60, passing:78, dribbling:74, defending:82, physical:78 },
      { id:"gatti", name:"F. Gatti",      pos:"CB",  rating:82, pace:74, shooting:38, passing:66, dribbling:58, defending:84, physical:84 },
      { id:"brem",  name:"G. Bremer",     pos:"CB",  rating:86, pace:76, shooting:42, passing:68, dribbling:65, defending:89, physical:86 },
      { id:"ale2",  name:"A. Sandro",     pos:"LB",  rating:80, pace:78, shooting:54, passing:74, dribbling:74, defending:76, physical:74 },
      { id:"loc",   name:"M. Locatelli",  pos:"CDM", rating:83, pace:68, shooting:68, passing:83, dribbling:78, defending:82, physical:76 },
      { id:"fab",   name:"F. Rabiot",     pos:"CDM", rating:85, pace:76, shooting:74, passing:84, dribbling:80, defending:78, physical:80 },
      { id:"wea",   name:"T. Weah",       pos:"RW",  rating:80, pace:90, shooting:72, passing:70, dribbling:82, defending:36, physical:70 },
      { id:"cost",  name:"F. Kostic",     pos:"LW",  rating:82, pace:80, shooting:68, passing:80, dribbling:78, defending:46, physical:72 },
      { id:"vla",   name:"D. Vlahović",   pos:"ST",  rating:87, pace:80, shooting:90, passing:68, dribbling:78, defending:36, physical:86 },
      { id:"yil",   name:"K. Yıldız",     pos:"CAM", rating:85, pace:80, shooting:82, passing:84, dribbling:90, defending:40, physical:70 },
    ]
  },

  // ── BUNDESLIGA ─────────────────────────────────────────────
  bayern_munich: {
    id: "bayern_munich", name: "Bayern Munich", league: "bundesliga",
    color: "#DC052D", color2: "#0066B2", rating: 89,
    formation: "4-2-3-1",
    players: [
      { id:"neue",  name:"M. Neuer",      pos:"GK",  rating:90, pace:46, shooting:16, passing:78, dribbling:46, defending:30, physical:84 },
      { id:"kinsl", name:"J. Kimmich",    pos:"RB",  rating:90, pace:74, shooting:76, passing:92, dribbling:84, defending:82, physical:76 },
      { id:"upame", name:"D. Upamecano",  pos:"CB",  rating:86, pace:84, shooting:44, passing:72, dribbling:68, defending:87, physical:86 },
      { id:"deligt", name:"M. de Ligt",   pos:"CB",  rating:85, pace:74, shooting:46, passing:72, dribbling:66, defending:87, physical:83 },
      { id:"dav",   name:"A. Davies",     pos:"LB",  rating:86, pace:96, shooting:56, passing:78, dribbling:84, defending:80, physical:74 },
      { id:"gor",   name:"L. Goretzka",   pos:"CDM", rating:86, pace:78, shooting:78, passing:83, dribbling:80, defending:80, physical:86 },
      { id:"sabi",  name:"J. Pavović",    pos:"CDM", rating:84, pace:72, shooting:68, passing:84, dribbling:78, defending:83, physical:80 },
      { id:"mul",   name:"T. Müller",     pos:"CAM", rating:87, pace:72, shooting:84, passing:88, dribbling:79, defending:60, physical:74 },
      { id:"coman", name:"K. Coman",      pos:"RW",  rating:85, pace:95, shooting:76, passing:76, dribbling:88, defending:36, physical:68 },
      { id:"kane",  name:"H. Kane",       pos:"ST",  rating:92, pace:70, shooting:95, passing:84, dribbling:82, defending:44, physical:84 },
      { id:"gna",   name:"S. Gnabry",     pos:"LW",  rating:85, pace:88, shooting:80, passing:76, dribbling:86, defending:38, physical:72 },
    ]
  },
  bvb: {
    id: "bvb", name: "Borussia Dortmund", league: "bundesliga",
    color: "#FDE100", color2: "#000000", rating: 84,
    formation: "4-2-3-1",
    players: [
      { id:"cob",   name:"G. Kobel",      pos:"GK",  rating:86, pace:40, shooting:12, passing:68, dribbling:36, defending:22, physical:80 },
      { id:"ryerson",name:"J. Ryerson",   pos:"RB",  rating:78, pace:82, shooting:54, passing:70, dribbling:70, defending:76, physical:74 },
      { id:"schlott",name:"N. Schlotterbeck",pos:"CB",rating:84,pace:76, shooting:44, passing:70, dribbling:66, defending:86, physical:84 },
      { id:"hum",   name:"M. Hummels",    pos:"CB",  rating:85, pace:66, shooting:44, passing:80, dribbling:68, defending:88, physical:80 },
      { id:"benz",  name:"R. Guerreiro",  pos:"LB",  rating:82, pace:80, shooting:62, passing:80, dribbling:80, defending:74, physical:68 },
      { id:"can",   name:"E. Can",        pos:"CDM", rating:83, pace:72, shooting:70, passing:78, dribbling:74, defending:82, physical:84 },
      { id:"sabitz",name:"M. Sabitzer",   pos:"CDM", rating:83, pace:78, shooting:74, passing:82, dribbling:80, defending:76, physical:78 },
      { id:"reus",  name:"M. Reus",       pos:"CAM", rating:84, pace:80, shooting:82, passing:85, dribbling:87, defending:46, physical:70 },
      { id:"brandt",name:"J. Brandt",     pos:"LW",  rating:82, pace:80, shooting:74, passing:80, dribbling:84, defending:38, physical:68 },
      { id:"haller",name:"S. Haller",     pos:"ST",  rating:82, pace:74, shooting:84, passing:66, dribbling:72, defending:36, physical:84 },
      { id:"adey",  name:"K. Adeyemi",    pos:"RW",  rating:83, pace:96, shooting:76, passing:70, dribbling:86, defending:32, physical:72 },
    ]
  },

  // ── LIGUE 1 ────────────────────────────────────────────────
  psg: {
    id: "psg", name: "Paris Saint-Germain", league: "ligue1",
    color: "#003370", color2: "#DA291C", rating: 88,
    formation: "4-3-3",
    players: [
      { id:"don",   name:"G. Donnarumma",  pos:"GK", rating:91, pace:48, shooting:14, passing:72, dribbling:40, defending:28, physical:86 },
      { id:"hac",   name:"A. Hakimi",      pos:"RB", rating:88, pace:92, shooting:68, passing:80, dribbling:84, defending:76, physical:78 },
      { id:"mar3",  name:"M. Marquinhos",  pos:"CB", rating:88, pace:76, shooting:46, passing:80, dribbling:74, defending:90, physical:82 },
      { id:"skrin", name:"M. Škriniar",    pos:"CB", rating:86, pace:72, shooting:42, passing:70, dribbling:65, defending:89, physical:84 },
      { id:"nuno",  name:"N. Mendes",      pos:"LB", rating:86, pace:90, shooting:60, passing:80, dribbling:84, defending:80, physical:74 },
      { id:"fab2",  name:"Fabian Ruiz",    pos:"CM", rating:85, pace:72, shooting:76, passing:88, dribbling:82, defending:68, physical:74 },
      { id:"zai",   name:"W. Zaïre-Emery", pos:"CM", rating:84, pace:80, shooting:74, passing:83, dribbling:84, defending:72, physical:72 },
      { id:"vit",   name:"V. Vitinha",     pos:"CM", rating:85, pace:76, shooting:72, passing:88, dribbling:86, defending:68, physical:68 },
      { id:"dem",   name:"O. Dembélé",     pos:"RW", rating:89, pace:94, shooting:82, passing:80, dribbling:93, defending:36, physical:72 },
      { id:"gon",   name:"G. Ramos",       pos:"ST", rating:86, pace:82, shooting:88, passing:72, dribbling:78, defending:36, physical:80 },
      { id:"brad",  name:"B. Barcola",     pos:"LW", rating:85, pace:93, shooting:80, passing:76, dribbling:88, defending:32, physical:70 },
    ]
  },
  monaco: {
    id: "monaco", name: "AS Monaco", league: "ligue1",
    color: "#CE1126", color2: "#FFFFFF", rating: 82,
    formation: "4-2-3-1",
    players: [
      { id:"nav",   name:"A. Nübel",       pos:"GK", rating:83, pace:42, shooting:12, passing:66, dribbling:36, defending:20, physical:78 },
      { id:"side",  name:"E. Sidibé",      pos:"RB", rating:80, pace:84, shooting:54, passing:70, dribbling:72, defending:78, physical:76 },
      { id:"maw",   name:"A. Maripán",     pos:"CB", rating:82, pace:72, shooting:38, passing:66, dribbling:60, defending:84, physical:82 },
      { id:"dis",   name:"D. Disasi",      pos:"CB", rating:82, pace:78, shooting:40, passing:68, dribbling:63, defending:84, physical:82 },
      { id:"car2",  name:"C. Caio Henrique",pos:"LB",rating:83, pace:82, shooting:58, passing:76, dribbling:78, defending:76, physical:72 },
      { id:"fof",   name:"Y. Fofana",      pos:"CDM",rating:84, pace:76, shooting:66, passing:78, dribbling:76, defending:84, physical:80 },
      { id:"camb",  name:"E. Camara",      pos:"CDM",rating:78, pace:74, shooting:62, passing:76, dribbling:74, defending:78, physical:78 },
      { id:"goba",  name:"W. Ben Yedder",  pos:"CAM",rating:83, pace:74, shooting:86, passing:78, dribbling:82, defending:36, physical:68 },
      { id:"volk",  name:"A. Volland",     pos:"RW", rating:80, pace:82, shooting:76, passing:72, dribbling:78, defending:38, physical:72 },
      { id:"god",   name:"K. Embolo",      pos:"ST", rating:82, pace:84, shooting:80, passing:66, dribbling:76, defending:38, physical:84 },
      { id:"gel",   name:"A. Gelson Martins",pos:"LW",rating:80,pace:92, shooting:70, passing:70, dribbling:82, defending:34, physical:68 },
    ]
  },
};

// Position coordinates on the pitch (for formation display)
const POSITION_COORDS = {
  "GK":  { x: 50, y: 90 },
  "CB":  { x: 50, y: 75 },
  "RB":  { x: 80, y: 78 },
  "LB":  { x: 20, y: 78 },
  "RWB": { x: 85, y: 65 },
  "LWB": { x: 15, y: 65 },
  "CDM": { x: 50, y: 62 },
  "CM":  { x: 50, y: 50 },
  "CAM": { x: 50, y: 38 },
  "RM":  { x: 80, y: 55 },
  "LM":  { x: 20, y: 55 },
  "RW":  { x: 80, y: 30 },
  "LW":  { x: 20, y: 30 },
  "ST":  { x: 50, y: 18 },
};

// Spread CB/CDM/CM positions for multi-player rows
function adjustPositions(players) {
  const posCount = {};
  players.forEach(p => {
    posCount[p.pos] = (posCount[p.pos] || 0) + 1;
  });
  const posIndex = {};
  return players.map(p => {
    const base = { ...POSITION_COORDS[p.pos] } || { x: 50, y: 50 };
    const total = posCount[p.pos];
    posIndex[p.pos] = (posIndex[p.pos] || 0);
    if (total > 1) {
      const step = 60 / (total + 1);
      base.x = 20 + step * (posIndex[p.pos] + 1);
    }
    posIndex[p.pos]++;
    return { ...p, px: base.x, py: base.y };
  });
}
