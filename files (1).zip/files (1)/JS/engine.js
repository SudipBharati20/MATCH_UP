// ============================================================
//  FIFA SIM — Match Simulation Engine
// ============================================================

class MatchEngine {
  constructor(homeTeam, awayTeam) {
    this.home = homeTeam;
    this.away = awayTeam;
    this.minutes = [];
    this.generate();
  }

  // Average team attribute
  _avg(team, attr) {
    return team.players.reduce((s, p) => s + (p[attr] || 0), 0) / team.players.length;
  }

  // Weighted team strength
  _strength(team) {
    return (
      this._avg(team, "shooting")  * 0.30 +
      this._avg(team, "passing")   * 0.25 +
      this._avg(team, "dribbling") * 0.20 +
      this._avg(team, "physical")  * 0.15 +
      this._avg(team, "pace")      * 0.10
    );
  }

  _rand(min, max) { return Math.random() * (max - min) + min; }
  _chance(prob)   { return Math.random() < prob; }

  _pickScorer(team) {
    const attackers = team.players.filter(p => ["ST","LW","RW","CAM"].includes(p.pos));
    if (!attackers.length) return team.players[Math.floor(Math.random() * team.players.length)];
    // Weighted by shooting
    const total = attackers.reduce((s, p) => s + p.shooting, 0);
    let rnd = Math.random() * total;
    for (const p of attackers) {
      rnd -= p.shooting;
      if (rnd <= 0) return p;
    }
    return attackers[0];
  }

  _pickAssist(team, scorer) {
    const midfielders = team.players.filter(p =>
      ["CM","CAM","CDM","LM","RM"].includes(p.pos) && p.id !== scorer.id
    );
    const pool = midfielders.length ? midfielders : team.players.filter(p => p.id !== scorer.id);
    const total = pool.reduce((s, p) => s + p.passing, 0);
    let rnd = Math.random() * total;
    for (const p of pool) {
      rnd -= p.passing;
      if (rnd <= 0) return p;
    }
    return pool[0];
  }

  generate() {
    const homeStr  = this._strength(this.home);
    const awayStr  = this._strength(this.away);
    const total    = homeStr + awayStr;
    const homeAdv  = homeStr / total;          // 0-1 home advantage
    const defHome  = this._avg(this.home, "defending");
    const defAway  = this._avg(this.away, "defending");

    // Possession (%)
    const homePoss = Math.round(homeAdv * 100);
    const awayPoss = 100 - homePoss;

    // Shots — based on strength difference
    const homeShots = Math.round(this._rand(8, 18) * homeAdv + 2);
    const awayShots = Math.round(this._rand(8, 18) * (1 - homeAdv) + 2);

    // Shots on target
    const homeSOT = Math.round(homeShots * this._rand(0.35, 0.55));
    const awaySOT = Math.round(awayShots * this._rand(0.35, 0.55));

    // Conversion rate affected by opposition defence
    const homeConvRate = Math.max(0.10, 0.35 - (defAway - 70) * 0.003);
    const awayConvRate = Math.max(0.10, 0.35 - (defHome - 70) * 0.003);

    const homeGoals = Math.round(homeSOT * homeConvRate * this._rand(0.7, 1.3));
    const awayGoals = Math.round(awaySOT * awayConvRate * this._rand(0.7, 1.3));

    // Corners, fouls, yellows, reds
    const homeCorners = Math.round(this._rand(3, 10) * homeAdv + 1);
    const awayCorners = Math.round(this._rand(3, 10) * (1 - homeAdv) + 1);
    const homeYellows = Math.round(this._rand(0, 3));
    const awayYellows = Math.round(this._rand(0, 3));
    const homeReds    = this._chance(0.07) ? 1 : 0;
    const awayReds    = this._chance(0.07) ? 1 : 0;

    // Build goal events
    const goalEvents = [];
    const usedMinutes = new Set();

    const addGoals = (count, team, isHome) => {
      for (let i = 0; i < count; i++) {
        let min;
        do { min = Math.floor(this._rand(1, 90)); } while (usedMinutes.has(min));
        usedMinutes.add(min);
        const scorer = this._pickScorer(team);
        const assist = this._chance(0.75) ? this._pickAssist(team, scorer) : null;
        goalEvents.push({ min, team: isHome ? "home" : "away", scorer, assist, type: "goal" });
      }
    };
    addGoals(homeGoals, this.home, true);
    addGoals(awayGoals, this.away, false);

    // Build yellow card events
    const cardEvents = [];
    const addCards = (count, team, isHome, color) => {
      for (let i = 0; i < count; i++) {
        let min;
        do { min = Math.floor(this._rand(10, 90)); } while (usedMinutes.has(min));
        usedMinutes.add(min);
        const player = team.players[Math.floor(Math.random() * team.players.length)];
        cardEvents.push({ min, team: isHome ? "home" : "away", player, color, type: "card" });
      }
    };
    addCards(homeYellows, this.home, true, "yellow");
    addCards(awayYellows, this.away, false, "yellow");
    if (homeReds) addCards(1, this.home, true, "red");
    if (awayReds) addCards(1, this.away, false, "red");

    // Combine and sort all events
    const allEvents = [...goalEvents, ...cardEvents].sort((a, b) => a.min - b.min);

    // Generate per-minute commentary and running score
    let homeScore = 0, awayScore = 0;
    const timeline = [];

    for (const evt of allEvents) {
      if (evt.type === "goal") {
        if (evt.team === "home") homeScore++; else awayScore++;
        timeline.push({
          min: evt.min,
          type: "goal",
          team: evt.team,
          scorer: evt.scorer,
          assist: evt.assist,
          homeScore,
          awayScore,
          text: this._goalText(evt.scorer, evt.assist, evt.team === "home" ? this.home : this.away),
        });
      } else {
        timeline.push({
          min: evt.min,
          type: "card",
          team: evt.team,
          player: evt.player,
          color: evt.color,
          homeScore,
          awayScore,
          text: `${evt.color === "yellow" ? "🟨" : "🟥"} ${evt.player.name} (${evt.team === "home" ? this.home.name : this.away.name}) receives a ${evt.color} card.`,
        });
      }
    }

    // Add commentary events at key moments (no goal/card)
    const commentaryMins = [5, 15, 25, 35, 45, 55, 65, 75, 85];
    commentaryMins.forEach(min => {
      if (!allEvents.find(e => e.min === min)) {
        timeline.push({
          min, type: "commentary", homeScore, awayScore,
          text: this._commentaryText(min, homeAdv, this.home, this.away),
        });
      }
    });

    timeline.sort((a, b) => a.min - b.min);

    // Player ratings (performance based on stats)
    const ratePlayer = (player, team, isHome) => {
      const base = this._rand(6.0, 7.2);
      const posBonus = {
        GK: 0, CB: 0.1, RB: 0.2, LB: 0.2, CDM: 0.2,
        CM: 0.3, CAM: 0.4, LM: 0.3, RM: 0.3,
        RW: 0.5, LW: 0.5, ST: 0.6, RWB: 0.2, LWB: 0.2,
      }[player.pos] || 0;
      const statBonus = (player.rating - 78) * 0.02;
      let rating = Math.min(10, Math.max(5.5, base + posBonus + statBonus));

      // Did they score or assist?
      const scored = timeline.filter(e => e.type === "goal" && e.team === (isHome ? "home" : "away") && e.scorer?.id === player.id).length;
      const assisted = timeline.filter(e => e.type === "goal" && e.team === (isHome ? "home" : "away") && e.assist?.id === player.id).length;
      rating += scored * 0.8 + assisted * 0.4;
      return Math.min(10, parseFloat(rating.toFixed(1)));
    };

    const homeRatings = Object.fromEntries(this.home.players.map(p => [p.id, ratePlayer(p, this.home, true)]));
    const awayRatings = Object.fromEntries(this.away.players.map(p => [p.id, ratePlayer(p, this.away, false)]));

    this.result = {
      homeGoals, awayGoals, homeScore: homeGoals, awayScore: awayGoals,
      homeShots, awayShots, homeSOT, awaySOT,
      homePoss, awayPoss,
      homeCorners, awayCorners,
      homeYellows, awayYellows, homeReds, awayReds,
      timeline,
      homeRatings, awayRatings,
    };

    this.minutes = timeline;
  }

  _goalText(scorer, assist, team) {
    const phrases = [
      `GOAL! ${scorer.name} strikes beautifully for ${team.name}!`,
      `${scorer.name} finds the net! ${team.name} take the lead!`,
      `What a finish by ${scorer.name}! The crowd goes wild!`,
      `${scorer.name} doesn't miss from there! ${team.name} score!`,
      `Brilliant goal from ${scorer.name}!`,
    ];
    let text = phrases[Math.floor(Math.random() * phrases.length)];
    if (assist) text += ` Assisted by ${assist.name}.`;
    return text;
  }

  _commentaryText(min, homeAdv, home, away) {
    if (min === 45) return `⏸ Half-time whistle! The referee brings the first half to a close.`;
    if (min === 85) return `⏱ Five minutes to go! The tension is palpable!`;
    const pool = [
      `${homeAdv > 0.5 ? home.name : away.name} are controlling the tempo here.`,
      `A strong challenge in midfield as both teams battle for possession.`,
      `The keeper is called into action with a routine save.`,
      `${home.name} look to press high — ${away.name} trying to break quickly.`,
      `A corner kick comes to nothing as the defence clears their lines.`,
      `Tension building in this match — neither side giving an inch.`,
      `Lovely one-two in midfield, but the final ball lets the attack down.`,
      `VAR check underway — no incident found, play resumes.`,
      `The fans are in full voice — incredible atmosphere here!`,
    ];
    return pool[Math.floor(Math.random() * pool.length)];
  }
}
