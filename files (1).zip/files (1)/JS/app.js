// ============================================================
//  FIFA SIM — UI Controller & App State
// ============================================================

const App = (() => {
  // ── STATE ─────────────────────────────────────────────────
  const state = {
    screen: "home",          // home | mode | team-select | lineup | match | stats
    mode: null,              // "single" | "multi"
    currentPicker: "home",   // which team we're picking: "home" | "away"
    homeTeam: null,
    awayTeam: null,
    homeLineup: null,
    awayLineup: null,
    matchResult: null,
    matchInterval: null,
    matchEventIndex: 0,
    matchMinute: 0,
    homeScore: 0,
    awayScore: 0,
    phase: "home-team",      // multi-only phase tracking
  };

  // ── SCREENS ───────────────────────────────────────────────
  function show(id) {
    document.querySelectorAll(".screen").forEach(s => s.classList.remove("active"));
    const el = document.getElementById(id);
    if (el) el.classList.add("active");
    state.screen = id;
  }

  // ── HOME SCREEN ───────────────────────────────────────────
  function initHome() {
    document.getElementById("btn-single").onclick = () => {
      state.mode = "single";
      state.currentPicker = "home";
      state.phase = "home-team";
      renderTeamSelect();
      show("screen-team-select");
    };
    document.getElementById("btn-multi").onclick = () => {
      state.mode = "multi";
      state.currentPicker = "home";
      state.phase = "home-team";
      renderTeamSelect();
      show("screen-team-select");
    };
  }

  // ── TEAM SELECT SCREEN ────────────────────────────────────
  function renderTeamSelect() {
    const isHome = state.currentPicker === "home";
    const playerNum = state.mode === "single"
      ? "Player"
      : (isHome ? "Player 1" : "Player 2");

    document.getElementById("team-select-title").textContent =
      `${playerNum} — Choose Your Team`;
    document.getElementById("team-select-subtitle").textContent =
      isHome
        ? (state.mode === "single" ? "Pick your squad from the Top 5 Leagues" : "Player 1: Pick your squad")
        : "Player 2: Pick your squad";

    const grid = document.getElementById("team-grid");
    grid.innerHTML = "";

    // League filter tabs
    const filterBar = document.getElementById("league-filter");
    filterBar.innerHTML = "";
    const allLeagues = ["all", ...Object.keys(LEAGUES)];
    allLeagues.forEach(lk => {
      const btn = document.createElement("button");
      btn.className = "league-tab" + (lk === "all" ? " active" : "");
      btn.textContent = lk === "all" ? "All Leagues" : LEAGUES[lk]?.name || lk;
      btn.dataset.league = lk;
      btn.onclick = () => {
        document.querySelectorAll(".league-tab").forEach(b => b.classList.remove("active"));
        btn.classList.add("active");
        renderTeamCards(lk);
      };
      filterBar.appendChild(btn);
    });

    renderTeamCards("all");
  }

  function renderTeamCards(leagueFilter) {
    const grid = document.getElementById("team-grid");
    grid.innerHTML = "";
    const isHome = state.currentPicker === "home";
    const disabledId = isHome ? null : state.homeTeam?.id;

    Object.values(TEAMS).forEach(team => {
      if (leagueFilter !== "all" && team.league !== leagueFilter) return;

      const card = document.createElement("div");
      card.className = "team-card" + (team.id === disabledId ? " disabled" : "");
      card.innerHTML = `
        <div class="team-badge" style="background:linear-gradient(135deg,${team.color},${team.color2 || '#fff'})">
          <span class="team-initial">${team.name.charAt(0)}</span>
        </div>
        <div class="team-info">
          <div class="team-name">${team.name}</div>
          <div class="team-meta">${LEAGUES[team.league]?.name} · OVR ${team.rating}</div>
        </div>
        <div class="team-ovr">${team.rating}</div>
      `;

      if (team.id !== disabledId) {
        card.onclick = () => selectTeam(team);
      }
      grid.appendChild(card);
    });
  }

  function selectTeam(team) {
    if (state.currentPicker === "home") {
      state.homeTeam = team;
      state.homeLineup = [...team.players]; // copy

      if (state.mode === "single") {
        // CPU picks random away team
        const others = Object.values(TEAMS).filter(t => t.id !== team.id);
        state.awayTeam = others[Math.floor(Math.random() * others.length)];
        state.awayLineup = [...state.awayTeam.players];
        renderLineup();
        show("screen-lineup");
      } else {
        // Multiplayer: now pick away team
        state.currentPicker = "away";
        renderTeamSelect();
      }
    } else {
      state.awayTeam = team;
      state.awayLineup = [...team.players];
      renderLineup();
      show("screen-lineup");
    }
  }

  // ── LINEUP SCREEN ─────────────────────────────────────────
  function renderLineup() {
    const home = state.homeTeam;
    const away = state.awayTeam;

    document.getElementById("lineup-home-name").textContent = home.name;
    document.getElementById("lineup-away-name").textContent = away.name;

    renderPitch("pitch-home", home, adjustPositions(state.homeLineup), "home");
    renderPitch("pitch-away", away, adjustPositions(state.awayLineup), "away");

    // Ratings
    const homeOvr = Math.round(home.players.reduce((s, p) => s + p.rating, 0) / home.players.length);
    const awayOvr = Math.round(away.players.reduce((s, p) => s + p.rating, 0) / away.players.length);
    document.getElementById("home-ovr").textContent = homeOvr;
    document.getElementById("away-ovr").textContent = awayOvr;

    // CPU label
    document.getElementById("away-label").textContent = state.mode === "single" ? "CPU" : "Player 2";

    document.getElementById("btn-kick-off").onclick = startMatch;
    document.getElementById("btn-lineup-back").onclick = () => {
      if (state.mode === "single") { state.currentPicker = "home"; renderTeamSelect(); show("screen-team-select"); }
      else { state.currentPicker = "away"; renderTeamSelect(); show("screen-team-select"); }
    };
  }

  function renderPitch(containerId, team, players, side) {
    const container = document.getElementById(containerId);
    container.innerHTML = "";
    container.style.position = "relative";

    players.forEach(player => {
      const dot = document.createElement("div");
      dot.className = "player-dot";
      dot.style.left = `${player.px}%`;
      // Flip away team
      dot.style.top = side === "away" ? `${100 - player.py}%` : `${player.py}%`;
      dot.style.background = team.color;
      dot.innerHTML = `
        <div class="dot-circle">${player.pos}</div>
        <div class="dot-name">${player.name.split(" ").pop()}</div>
      `;
      container.appendChild(dot);
    });
  }

  // ── MATCH SCREEN ──────────────────────────────────────────
  function startMatch() {
    show("screen-match");

    // Build engine
    const engine = new MatchEngine(
      { ...state.homeTeam, players: state.homeLineup },
      { ...state.awayTeam, players: state.awayLineup }
    );
    state.matchResult = engine.result;
    state.matchEventIndex = 0;
    state.matchMinute = 0;
    state.homeScore = 0;
    state.awayScore = 0;

    // Setup UI
    document.getElementById("match-home-name").textContent = state.homeTeam.name;
    document.getElementById("match-away-name").textContent = state.awayTeam.name;
    document.getElementById("match-score").textContent = "0 – 0";
    document.getElementById("match-minute").textContent = "0'";
    document.getElementById("commentary-feed").innerHTML = "";

    // Reset bar stats
    updateLiveStats(0, 0, 50, 50, 0, 0, 0, 0);

    // Progress bar
    const progressBar = document.getElementById("match-progress");
    progressBar.style.width = "0%";

    const timeline = state.matchResult.timeline;

    // Simulate 90 minutes in 60 seconds (each second = 1.5 minutes real time)
    let currentMin = 0;

    clearInterval(state.matchInterval);
    state.matchInterval = setInterval(() => {
      currentMin += 1.5;
      if (currentMin > 90) currentMin = 90;

      const displayMin = Math.round(currentMin);
      document.getElementById("match-minute").textContent = `${displayMin}'`;
      progressBar.style.width = `${(currentMin / 90) * 100}%`;

      // Check for events up to currentMin
      while (
        state.matchEventIndex < timeline.length &&
        timeline[state.matchEventIndex].min <= currentMin
      ) {
        const evt = timeline[state.matchEventIndex];
        processEvent(evt);
        state.matchEventIndex++;
      }

      if (currentMin >= 90) {
        clearInterval(state.matchInterval);
        setTimeout(() => {
          addCommentary("⏱ Full-time! The referee blows the final whistle!", "system");
          document.getElementById("btn-fulltime").style.display = "flex";
        }, 800);
      }
    }, 667); // 667ms per tick ≈ 60 seconds total
  }

  function processEvent(evt) {
    if (evt.type === "goal") {
      if (evt.team === "home") state.homeScore++;
      else state.awayScore++;

      document.getElementById("match-score").textContent = `${state.homeScore} – ${state.awayScore}`;
      addCommentary(`⚽ ${evt.min}' — ${evt.text}`, "goal");
      flashScore();
    } else if (evt.type === "card") {
      addCommentary(`${evt.min}' — ${evt.text}`, "card");
    } else {
      addCommentary(`${evt.min}' — ${evt.text}`, "commentary");
    }

    // Update live stats
    const r = state.matchResult;
    const progress = Math.min(evt.min / 90, 1);
    updateLiveStats(
      Math.round(r.homeShots * progress), Math.round(r.awayShots * progress),
      r.homePoss, r.awayPoss,
      Math.round(r.homeSOT * progress), Math.round(r.awaySOT * progress),
      Math.round(r.homeCorners * progress), Math.round(r.awayCorners * progress)
    );
  }

  function addCommentary(text, type) {
    const feed = document.getElementById("commentary-feed");
    const item = document.createElement("div");
    item.className = `commentary-item ${type}`;
    item.textContent = text;
    feed.prepend(item);
    item.animate([
      { opacity: 0, transform: "translateY(-10px)" },
      { opacity: 1, transform: "translateY(0)" }
    ], { duration: 400, fill: "forwards" });
  }

  function flashScore() {
    const score = document.getElementById("match-score");
    score.classList.add("flash");
    setTimeout(() => score.classList.remove("flash"), 600);
  }

  function updateLiveStats(hSh, aSh, hPoss, aPoss, hSOT, aSOT, hCorn, aCorn) {
    setStat("stat-shots",    hSh,   aSh);
    setStat("stat-poss",     hPoss, aPoss, true);
    setStat("stat-sot",      hSOT,  aSOT);
    setStat("stat-corners",  hCorn, aCorn);
  }

  function setStat(id, home, away, isPercent) {
    const row = document.getElementById(id);
    if (!row) return;
    row.querySelector(".stat-home").textContent = isPercent ? `${home}%` : home;
    row.querySelector(".stat-away").textContent = isPercent ? `${away}%` : away;
    const total = home + away || 1;
    row.querySelector(".bar-home").style.width = `${(home / total) * 100}%`;
    row.querySelector(".bar-away").style.width = `${(away / total) * 100}%`;
  }

  // ── STATS / POST-MATCH SCREEN ─────────────────────────────
  function showStats() {
    show("screen-stats");
    const r = state.matchResult;
    const home = state.homeTeam;
    const away = state.awayTeam;

    document.getElementById("stats-home-name").textContent = home.name;
    document.getElementById("stats-away-name").textContent = away.name;
    document.getElementById("stats-score").textContent = `${r.homeGoals} – ${r.awayGoals}`;

    // Determine result
    let resultText = "Draw!";
    if (r.homeGoals > r.awayGoals) resultText = `${home.name} Win! 🏆`;
    else if (r.awayGoals > r.homeGoals) resultText = `${away.name} Win! 🏆`;
    document.getElementById("stats-result").textContent = resultText;

    // Full stats table
    const statsData = [
      ["Possession",    `${r.homePoss}%`,    `${r.awayPoss}%`],
      ["Shots",          r.homeShots,          r.awayShots],
      ["Shots on Target",r.homeSOT,            r.awaySOT],
      ["Corners",        r.homeCorners,        r.awayCorners],
      ["Yellow Cards",   r.homeYellows,        r.awayYellows],
      ["Red Cards",      r.homeReds,           r.awayReds],
    ];

    const table = document.getElementById("stats-table");
    table.innerHTML = statsData.map(([label, h, a]) => `
      <div class="stats-row">
        <span class="stats-val home">${h}</span>
        <span class="stats-label">${label}</span>
        <span class="stats-val away">${a}</span>
      </div>
    `).join("");

    // Player ratings
    renderPlayerRatings("ratings-home", home.players, r.homeRatings, home.color);
    renderPlayerRatings("ratings-away", away.players, r.awayRatings, away.color);

    // Goal scorers
    const goals = r.timeline.filter(e => e.type === "goal");
    const scorersList = document.getElementById("scorers-list");
    if (!goals.length) {
      scorersList.innerHTML = `<div class="no-goals">No goals scored</div>`;
    } else {
      scorersList.innerHTML = goals.map(e => `
        <div class="scorer-item ${e.team}">
          <span class="scorer-min">${e.min}'</span>
          <span class="scorer-icon">⚽</span>
          <span class="scorer-name">${e.scorer.name}</span>
          ${e.assist ? `<span class="scorer-assist">(${e.assist.name})</span>` : ""}
          <span class="scorer-team">${e.team === "home" ? state.homeTeam.name : state.awayTeam.name}</span>
        </div>
      `).join("");
    }

    document.getElementById("btn-play-again").onclick = playAgain;
  }

  function renderPlayerRatings(containerId, players, ratings, color) {
    const container = document.getElementById(containerId);
    container.innerHTML = players.map(p => {
      const r = ratings[p.id] || 6.5;
      const ratingClass = r >= 8.5 ? "gold" : r >= 7.5 ? "green" : r >= 6.5 ? "normal" : "poor";
      return `
        <div class="player-rating-row">
          <span class="pr-pos" style="background:${color}">${p.pos}</span>
          <span class="pr-name">${p.name}</span>
          <span class="pr-score ${ratingClass}">${r.toFixed(1)}</span>
        </div>
      `;
    }).join("");
  }

  function playAgain() {
    state.homeTeam = null; state.awayTeam = null;
    state.homeLineup = null; state.awayLineup = null;
    state.matchResult = null;
    state.homeScore = 0; state.awayScore = 0;
    clearInterval(state.matchInterval);
    show("screen-home");
  }

  // ── INIT ──────────────────────────────────────────────────
  function init() {
    initHome();

    // Back buttons
    document.getElementById("btn-team-back").onclick = () => {
      if (state.currentPicker === "away") {
        state.currentPicker = "home";
        renderTeamSelect();
      } else {
        show("screen-home");
      }
    };

    // Full time button
    document.getElementById("btn-fulltime").onclick = () => {
      document.getElementById("btn-fulltime").style.display = "none";
      showStats();
    };

    show("screen-home");
  }

  return { init };
})();

document.addEventListener("DOMContentLoaded", App.init);
